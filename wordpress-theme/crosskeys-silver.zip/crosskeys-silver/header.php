<?php
/**
 * header.php — Crosskeys Silver Band Theme
 * Outputs the <head>, Google Fonts preconnect, and the fixed navigation header.
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo( 'charset' ); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<!-- Header & Navigation -->
<header id="main-header">
  <div class="nav-container">

    <!-- Logo -->
    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="logo-wrapper" id="nav-logo-link">
      <?php
      if ( has_custom_logo() ) {
          $logo_id  = get_theme_mod( 'custom_logo' );
          $logo_url = wp_get_attachment_image_url( $logo_id, 'full' );
          echo '<img src="' . esc_url( $logo_url ) . '" alt="' . esc_attr( get_bloginfo( 'name' ) ) . ' Logo" class="logo-img">';
      } else {
          echo '<img src="' . esc_url( get_template_directory_uri() . '/images/logo.png' ) . '" alt="Crosskeys Silver Band Logo" class="logo-img">';
      }
      ?>
      <span class="logo-text brand-font">Crosskeys<span class="logo-sub accent-text">Silver Band</span></span>
    </a>

    <!-- Mobile hamburger -->
    <button class="nav-toggle" aria-label="Toggle Navigation" id="mobile-menu-btn">
      <span class="hamburger"></span>
    </button>

    <!-- Navigation links -->
    <nav class="nav-links" id="navigation-bar" role="navigation" aria-label="Primary Navigation">
      <?php if ( is_front_page() ) : ?>
        <a href="#about"      class="nav-item">About Us</a>
        <a href="#conductor"  class="nav-item">Musical Director</a>
        <a href="#vacancies"  class="nav-item">Vacancies</a>
        <a href="#rehearsals" class="nav-item">Rehearsals</a>
        <a href="#contact"    class="nav-item">Contact</a>
        <a href="<?php echo esc_url( get_permalink( get_page_by_path( 'policies' ) ) ); ?>" class="nav-item">Policies</a>
      <?php else : ?>
        <a href="<?php echo esc_url( home_url( '/#about' ) ); ?>"      class="nav-item">About Us</a>
        <a href="<?php echo esc_url( home_url( '/#conductor' ) ); ?>"  class="nav-item">Musical Director</a>
        <a href="<?php echo esc_url( home_url( '/#vacancies' ) ); ?>"  class="nav-item">Vacancies</a>
        <a href="<?php echo esc_url( home_url( '/#rehearsals' ) ); ?>" class="nav-item">Rehearsals</a>
        <a href="<?php echo esc_url( home_url( '/#contact' ) ); ?>"    class="nav-item">Contact</a>
        <a href="<?php echo esc_url( get_permalink( get_page_by_path( 'policies' ) ) ); ?>"
           class="nav-item<?php echo ( is_page( 'policies' ) ? ' active' : '' ); ?>">Policies</a>
      <?php endif; ?>
    </nav>

  </div>
</header>
